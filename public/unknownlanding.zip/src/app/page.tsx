import Link from "next/link";
import Image from "next/image";

export default function Component() {
  return (
    <div className="flex flex-col min-h-[100dvh] bg-[#f1c40f]">
      <header className="px-4 lg:px-6 h-14 flex items-center">
        <Link href="#" className="flex items-center justify-center" prefetch={false}>
          <Image src="/meme-coin-logo.png" width={40} height={40} alt="Meme Coin Logo" className="mr-2" />
          <span className="text-2xl font-bold text-[#2c3e50]">Meme Coin</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link
            href="#"
            className="text-sm font-medium hover:underline underline-offset-4 text-[#2c3e50]"
            prefetch={false}
          >
            Features
          </Link>
          <Link
            href="#"
            className="text-sm font-medium hover:underline underline-offset-4 text-[#2c3e50]"
            prefetch={false}
          >
            Tokenomics
          </Link>
          <Link
            href="#"
            className="text-sm font-medium hover:underline underline-offset-4 text-[#2c3e50]"
            prefetch={false}
          >
            Buy
          </Link>
          <Link
            href="#"
            className="text-sm font-medium hover:underline underline-offset-4 text-[#2c3e50]"
            prefetch={false}
          >
            Stake
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6 flex flex-col items-center text-center">
            <Image src="/meme-coin-logo.png" width={100} height={100} alt="Meme Coin Logo" className="mb-4" />
            <h1 className="text-4xl font-bold tracking-tighter text-[#2c3e50] mb-4">Meme Coin</h1>
            <p className="max-w-[600px] text-[#7f8c8d] md:text-xl">
              Unleash the power of memes and blockchain technology with Meme Coin, the ultimate decentralized currency
              for the internet generation.
            </p>
            <div className="flex flex-col gap-2 min-[400px]:flex-row mt-6">
              <Link
                href="#"
                className="inline-flex h-10 items-center justify-center rounded-md bg-[#2980b9] px-8 text-sm font-medium text-white shadow transition-colors hover:bg-[#2980b9]/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                prefetch={false}
              >
                Buy Meme Coin
              </Link>
              <Link
                href="#"
                className="inline-flex h-10 items-center justify-center rounded-md border border-[#2980b9] bg-[#f1c40f] px-8 text-sm font-medium shadow-sm transition-colors hover:bg-[#f39c12] hover:text-white focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                prefetch={false}
              >
                Stake Meme Coin
              </Link>
            </div>
          </div>
        </section>
        <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-[#f39c12]">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-[#2c3e50]">Key Features</h2>
                <p className="max-w-[900px] text-[#7f8c8d] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Meme Coin is packed with innovative features that make it the ultimate meme-powered cryptocurrency.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <ul className="grid gap-6">
                  <li>
                    <div className="grid gap-1">
                      <h3 className="text-xl font-bold text-[#2c3e50]">Deflationary Tokenomics</h3>
                      <p className="text-[#7f8c8d]">
                        Meme Coin has a built-in burning mechanism that reduces the total supply over time, making it a
                        scarce and valuable asset.
                      </p>
                    </div>
                  </li>
                  <li>
                    <div className="grid gap-1">
                      <h3 className="text-xl font-bold text-[#2c3e50]">Meme-Powered Ecosystem</h3>
                      <p className="text-[#7f8c8d]">
                        Meme Coin integrates with popular meme platforms and communities, allowing users to earn and
                        spend the coin through meme-related activities.
                      </p>
                    </div>
                  </li>
                  <li>
                    <div className="grid gap-1">
                      <h3 className="text-xl font-bold text-[#2c3e50]">Decentralized Governance</h3>
                      <p className="text-[#7f8c8d]">
                        Meme Coin holders can participate in the project&apos;s decision-making process, ensuring the
                        community&apos;s voice is heard.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <Image
                src="/fullbody.png"
                width={420}
                height={594}
                alt="Meme Coin Features"
              />
            </div>
          </div>
        </section>
        <section id="tokenomics" className="w-full py-12 md:py-24 lg:py-32 bg-[#f1c40f]">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-[#2c3e50]">Tokenomics</h2>
                <p className="max-w-[900px] text-[#7f8c8d] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Meme Coin&apos;s tokenomics are designed to incentivize long-term holding and sustainable growth.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-2 lg:gap-12">
              <Image
                src="/piechart.png"
                width={550}
                height={310}
                alt="Meme Coin Tokenomics"
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full lg:order-last"
              />
              <div className="flex flex-col justify-center space-y-4">
                <ul className="grid gap-6">
                  <li>
                    <div className="grid gap-1">
                      <h3 className="text-xl font-bold text-[#2c3e50]">Total Supply: 1 Billion</h3>
                      <p className="text-[#7f8c8d]">
                        Meme Coin has a fixed total supply of 1 billion tokens, ensuring scarcity and value.
                      </p>
                    </div>
                  </li>
                  <li>
                    <div className="grid gap-1">
                      <h3 className="text-xl font-bold text-[#2c3e50]">Deflationary Mechanism</h3>
                      <p className="text-[#7f8c8d]">
                        A portion of every transaction is automatically burned, reducing the total supply over time and
                        increasing the value of each token.
                      </p>
                    </div>
                  </li>
                  <li>
                    <div className="grid gap-1">
                      <h3 className="text-xl font-bold text-[#2c3e50]">Staking Rewards</h3>
                      <p className="text-[#7f8c8d]">
                        Meme Coin holders can earn passive income by staking their tokens, further incentivizing
                        long-term holding.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
        <section id="buy" className="w-full py-12 md:py-24 lg:py-32 bg-[#f39c12]">
          <div className="container px-4 md:px-6 flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-[#2c3e50]">Buy Meme Coin</h2>
              <p className="max-w-[900px] text-[#7f8c8d] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Acquire Meme Coin and join the meme-powered revolution. You can buy Meme Coin directly on our website or
                through popular decentralized exchanges.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link
                href="#"
                className="inline-flex h-10 items-center justify-center rounded-md bg-[#2980b9] px-8 text-sm font-medium text-white shadow transition-colors hover:bg-[#2980b9]/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                prefetch={false}
              >
                Buy on Website
              </Link>
              <Link
                href="#"
                className="inline-flex h-10 items-center justify-center rounded-md border border-[#2980b9] bg-[#f1c40f] px-8 text-sm font-medium shadow-sm transition-colors hover:bg-[#f39c12] hover:text-white focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                prefetch={false}
              >
                Buy on DEX
              </Link>
            </div>
          </div>
        </section>
        <section id="stake" className="w-full py-12 md:py-24 lg:py-32 bg-[#f1c40f]">
          <div className="container px-4 md:px-6 flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-[#2c3e50]">Stake Meme Coin</h2>
              <p className="max-w-[900px] text-[#7f8c8d] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Earn passive income by staking your Meme Coin. Enjoy high APYs and help secure the Meme Coin network.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link
                href="#"
                className="inline-flex h-10 items-center justify-center rounded-md bg-[#2980b9] px-8 text-sm font-medium text-white shadow transition-colors hover:bg-[#2980b9]/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                prefetch={false}
              >
                Stake Meme Coin
              </Link>
              <Link
                href="#"
                className="inline-flex h-10 items-center justify-center rounded-md border border-[#2980b9] bg-[#f39c12] px-8 text-sm font-medium shadow-sm transition-colors hover:bg-[#f39c12] hover:text-white focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                prefetch={false}
              >
                Learn More
              </Link>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t bg-[#2c3e50]">
        <p className="text-xs text-[#f1c40f]">&copy; 2024 Meme Coin. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link href="#" className="text-xs hover:underline underline-offset-4 text-[#f1c40f]" prefetch={false}>
            Terms of Service
          </Link>
          <Link href="#" className="text-xs hover:underline underline-offset-4 text-[#f1c40f]" prefetch={false}>
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  );
}
